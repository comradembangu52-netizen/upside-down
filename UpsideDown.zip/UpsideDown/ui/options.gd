extends Control
## Options : volumes, plein écran, progression.
const UITheme := preload("res://scripts/ui_theme.gd")

var _music_label: Label
var _sfx_label: Label
var _full_btn: Button
var _info: Label


func _ready() -> void:
	theme = UITheme.make_theme()
	UITheme.add_background(self)
	var box := UITheme.make_center_box(self, 12)
	box.add_child(UITheme.make_label("OPTIONS", 56))
	_music_label = _volume_row(box, "MUSIQUE", _music_step)
	_sfx_label = _volume_row(box, "EFFETS", _sfx_step)
	_full_btn = UITheme.make_button("", _toggle_fullscreen, 640.0)
	box.add_child(_full_btn)
	box.add_child(UITheme.make_button("DÉVERROUILLER LES 5 NIVEAUX", _unlock, 640.0))
	box.add_child(UITheme.make_button("RÉINITIALISER LA PROGRESSION", _reset, 640.0))
	_info = UITheme.make_label("", 20, Color(0.7, 0.7, 0.7))
	box.add_child(_info)
	var back := UITheme.make_button("RETOUR", GameState.go_to_menu, 640.0)
	box.add_child(back)
	_refresh()
	back.grab_focus()


func _volume_row(parent: Container, title: String, step: Callable) -> Label:
	var row := HBoxContainer.new()
	row.alignment = BoxContainer.ALIGNMENT_CENTER
	row.add_theme_constant_override("separation", 12)
	parent.add_child(row)
	var t := UITheme.make_label(title, 24)
	t.custom_minimum_size = Vector2(220, 0)
	row.add_child(t)
	row.add_child(UITheme.make_button("-", step.bind(-0.1), 70.0))
	var v := UITheme.make_label("", 24)
	v.custom_minimum_size = Vector2(120, 0)
	row.add_child(v)
	row.add_child(UITheme.make_button("+", step.bind(0.1), 70.0))
	return v


func _refresh() -> void:
	_music_label.text = "%d %%" % int(round(GameState.music_volume * 100.0))
	_sfx_label.text = "%d %%" % int(round(GameState.sfx_volume * 100.0))
	_full_btn.text = "PLEIN ÉCRAN : %s" % ("OUI" if GameState.fullscreen else "NON")


func _music_step(d: float) -> void:
	GameState.set_music_volume(GameState.music_volume + d)
	_refresh()


func _sfx_step(d: float) -> void:
	GameState.set_sfx_volume(GameState.sfx_volume + d)
	_refresh()


func _toggle_fullscreen() -> void:
	GameState.set_fullscreen(not GameState.fullscreen)
	_refresh()


func _unlock() -> void:
	GameState.unlock_all()
	_info.text = "Tous les niveaux sont déverrouillés."


func _reset() -> void:
	GameState.reset_progress()
	_info.text = "Progression réinitialisée."


func _unhandled_input(event: InputEvent) -> void:
	if event.is_action_pressed("pause"):
		GameState.go_to_menu()
