extends Control
## Menu principal : JOUER, NIVEAUX, OPTIONS, QUITTER.
const UITheme := preload("res://scripts/ui_theme.gd")


func _ready() -> void:
	theme = UITheme.make_theme()
	UITheme.add_background(self)
	var box := UITheme.make_center_box(self, 12)
	UITheme.add_title(box, "UPSIDE DOWN", 88)
	box.add_child(Control.new())
	var play := UITheme.make_button("JOUER", _on_play)
	box.add_child(play)
	box.add_child(UITheme.make_button("NIVEAUX", _on_levels))
	box.add_child(UITheme.make_button("OPTIONS", _on_options))
	box.add_child(UITheme.make_button("QUITTER", _on_quit))
	for c in box.get_children():
		if c is Button:
			c.size_flags_horizontal = Control.SIZE_SHRINK_CENTER
	play.grab_focus()


func _on_play() -> void:
	# Reprend au niveau le plus avancé débloqué.
	GameState.start_level(GameState.unlocked_level)


func _on_levels() -> void:
	GameState.change_scene(GameState.LEVEL_SELECT)


func _on_options() -> void:
	GameState.change_scene(GameState.OPTIONS_SCENE)


func _on_quit() -> void:
	GameState.quit_game()
