extends CanvasLayer
## Menu pause (Échap). Fonctionne pendant que l'arbre de scène est en pause.
const UITheme := preload("res://scripts/ui_theme.gd")

var _root: Control
var _resume_btn: Button


func _ready() -> void:
	process_mode = Node.PROCESS_MODE_ALWAYS
	layer = 50
	_root = Control.new()
	_root.theme = UITheme.make_theme()
	add_child(_root)
	_root.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	var dim := ColorRect.new()
	dim.color = Color(0, 0, 0, 0.8)
	_root.add_child(dim)
	dim.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	var box := UITheme.make_center_box(_root, 12)
	box.add_child(UITheme.make_label("PAUSE", 64))
	_resume_btn = UITheme.make_button("REPRENDRE", close)
	box.add_child(_resume_btn)
	box.add_child(UITheme.make_button("RECOMMENCER", _restart))
	box.add_child(UITheme.make_button("NIVEAUX", _levels))
	box.add_child(UITheme.make_button("MENU PRINCIPAL", _menu))
	for c in box.get_children():
		if c is Button:
			c.size_flags_horizontal = Control.SIZE_SHRINK_CENTER
	visible = false


func is_open() -> bool:
	return visible


func open() -> void:
	visible = true
	get_tree().paused = true
	_resume_btn.grab_focus()


func close() -> void:
	visible = false
	get_tree().paused = false


func _restart() -> void:
	GameState.restart_level()


func _levels() -> void:
	GameState.change_scene(GameState.LEVEL_SELECT)


func _menu() -> void:
	GameState.go_to_menu()


func _unhandled_input(event: InputEvent) -> void:
	if visible and event.is_action_pressed("pause"):
		close()
		get_viewport().set_input_as_handled()
