extends Control
## Sélection des cinq niveaux ; les niveaux se débloquent en terminant le précédent.
const UITheme := preload("res://scripts/ui_theme.gd")


func _ready() -> void:
	theme = UITheme.make_theme()
	UITheme.add_background(self)
	var box := UITheme.make_center_box(self, 12)
	box.add_child(UITheme.make_label("NIVEAUX", 56))
	var first: Button = null
	for i in range(1, GameState.level_count() + 1):
		var label: String
		if GameState.is_unlocked(i):
			label = "%d  %s" % [i, GameState.level_name(i)]
			var key := str(i)
			if GameState.best_times.has(key):
				label += "   [%s]" % UITheme.format_time(float(GameState.best_times[key]))
		else:
			label = "%d  -- VERROUILLÉ --" % i
		var b := UITheme.make_button(label, _on_level.bind(i), 640.0)
		b.disabled = not GameState.is_unlocked(i)
		box.add_child(b)
		if first == null and not b.disabled:
			first = b
	var back := UITheme.make_button("RETOUR", GameState.go_to_menu, 640.0)
	box.add_child(back)
	(first if first != null else back).grab_focus()


func _on_level(n: int) -> void:
	GameState.start_level(n)


func _unhandled_input(event: InputEvent) -> void:
	if event.is_action_pressed("pause"):
		GameState.go_to_menu()
