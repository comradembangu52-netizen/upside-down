extends CanvasLayer
## Écran de victoire d'un niveau (temps, morts, suite).
const UITheme := preload("res://scripts/ui_theme.gd")


func _ready() -> void:
	process_mode = Node.PROCESS_MODE_ALWAYS
	layer = 60
	visible = false


func open(time: float, deaths: int, has_next: bool) -> void:
	var root := Control.new()
	root.theme = UITheme.make_theme()
	add_child(root)
	root.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	var dim := ColorRect.new()
	dim.color = Color(0, 0, 0, 0.88)
	root.add_child(dim)
	dim.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	var box := UITheme.make_center_box(root, 12)
	box.add_child(UITheme.make_label("NIVEAU TERMINÉ", 60))
	box.add_child(UITheme.make_label(GameState.level_name(GameState.current_level), 28, Color(0.75, 0.75, 0.75)))
	box.add_child(UITheme.make_label("Temps : %s    Chutes : %d" % [UITheme.format_time(time), deaths], 26))
	if GameState.last_best:
		box.add_child(UITheme.make_label("Nouveau record !", 22))
	box.add_child(Control.new())
	var next_text := "NIVEAU SUIVANT" if has_next else "LA FIN"
	var next := UITheme.make_button(next_text, GameState.next_level)
	box.add_child(next)
	box.add_child(UITheme.make_button("REJOUER", GameState.restart_level))
	box.add_child(UITheme.make_button("MENU PRINCIPAL", GameState.go_to_menu))
	for c in box.get_children():
		if c is Button:
			c.size_flags_horizontal = Control.SIZE_SHRINK_CENTER
	visible = true
	get_tree().paused = true
	next.grab_focus()
