extends Control
## Écran de fin : texte qui apparaît lentement, puis retour au menu.
const UITheme := preload("res://scripts/ui_theme.gd")

const STORY := "La lanterne brille de nouveau.\n\nLe monde est enfin en équilibre...\nou peut-être est-il toujours à l'envers ?\n\nL'explorateur sourit, et éteint sa lampe."


func _ready() -> void:
	theme = UITheme.make_theme()
	UITheme.add_background(self)
	var box := UITheme.make_center_box(self, 18)
	box.add_child(UITheme.make_label("FIN", 80))
	var text := UITheme.make_label(STORY, 28)
	text.visible_ratio = 0.0
	box.add_child(text)
	box.add_child(UITheme.make_label("MERCI D'AVOIR JOUÉ À UPSIDE DOWN", 24, Color(0.75, 0.75, 0.75)))
	var btn := UITheme.make_button("MENU PRINCIPAL", GameState.go_to_menu)
	btn.size_flags_horizontal = Control.SIZE_SHRINK_CENTER
	box.add_child(btn)
	btn.grab_focus()
	var tw := create_tween()
	tw.tween_property(text, "visible_ratio", 1.0, 5.0)
