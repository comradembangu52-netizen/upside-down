# UPSIDE DOWN — jeu de plateforme et de réflexion 1-bit (Godot 4.7.2, GDScript)

Un petit explorateur à lanterne retourne le monde à 180° avec MAJ : la caméra pivote, la gravité s'inverse,
le plafond devient le sol. Le personnage reste toujours droit à l'écran.

## Ouvrir et lancer
1. Installe Godot 4.7.2 (version standard, pas .NET).
2. Dans le gestionnaire de projets : **Importer** → sélectionne `UpsideDown.zip` (ou le fichier `project.godot` du dossier décompressé) → **Importer et modifier**.
3. Laisse Godot importer les ressources la première fois (barre de progression en bas à droite). Des erreurs rouges transitoires au tout premier chargement sont normales ; si elles persistent, ferme puis rouvre le projet.
4. Appuie sur **F5** (la scène principale est `res://ui/main_menu.tscn`). Renderer : Compatibility.

## Commandes
| Action | Touches |
|---|---|
| Gauche / droite | Flèches ou A (Q) / D |
| Sauter | Espace (ou flèche haut) |
| Inverser le monde | MAJ |
| Pause | Échap |
| Recommencer le niveau | R |

MAJ fonctionne au sol comme en l'air (délai de 0,65 s entre deux inversions). Quand le monde est retourné, « droite » reste la droite de l'écran.

## Les 5 niveaux (débloqués dans l'ordre)
1. **The Forgotten Forest** — déplacement, saut, première inversion, gouffres et piques.
2. **The Broken Ruins** — plateformes suspendues, plafond piégé, inversion en plein saut.
3. **The Silent Temple** — clés et portes verrouillées, leviers et grilles (deux leviers pour une grille).
4. **The Dark Depths** — plateformes mobiles horizontales et verticales, enchaînement d'inversions.
5. **The Last Light** — trois éclats de lumière à réunir pendant que la lanterne faiblit ; l'autel final s'ouvre avec les trois éclats.

Éléments : `^` piques (sol), `V` piques (plafond), checkpoints (lanternes de repos ; on réapparaît toujours monde à l'endroit), clés, leviers (au contact), éclats.
Menu Options : volumes, plein écran, déverrouiller les 5 niveaux (pratique pour tester), réinitialiser la progression. Sauvegarde dans `user://upside_down_save.cfg`.

## Structure
```
project.godot        icon.svg
scenes/              game.tscn, player.tscn, objects/ (clé, levier, grille, porte, piques, checkpoint, sortie, plateforme mobile, torche, éclat)
scripts/             game_state.gd (autoload), game.gd, player.gd, level_builder.gd, hud.gd, ui_theme.gd, objets…
levels/              level_1.gd … level_5.gd (cartes ASCII + indices + plateformes mobiles)
ui/                  main_menu, level_select, options, pause_menu, victory, ending (.tscn + .gd)
textures/ audio/ assets/   ressources (tuiles, sprites, sons, police, licences)
```

## Modifier un niveau
Ouvre `levels/level_N.gd` : `DATA["map"]` est une grille de 14 lignes (1 caractère = 1 tuile de 16 px). Légende dans l'en-tête du fichier.
Le sol occupe les lignes 12-13, le plafond les lignes 0-1 ; le joueur se tient sur la ligne 11 (sol) ou 2 (plafond).

## État de vérification (honnêteté)
- **Le jeu n'a PAS été exécuté dans Godot** : il n'y avait pas de moteur Godot dans l'environnement de génération.
- Vérifié : tous les chemins `res://` référencés existent ; chaque niveau est rectangulaire (14 lignes) ; les fichiers sons utilisés existent.
- Vérifié par une **simulation Python approximative** de la physique (mêmes constantes que `player.gd`) : les 5 niveaux ont une route jusqu'à la sortie (plateformes mobiles approximées par des dalles fixes ; le timing réel des plateformes du niveau 4 et du 5 n'est donc pas validé).
- À surveiller au premier lancement : erreurs de script dans la console de Godot, réglage de difficulté (constantes en tête de `player.gd`), apparence des tuiles.

## Crédits
Tuiles : Kenney « 1-Bit Platformer Pack » (CC0). Torche et colonne : pack « 1-Bit Ruins » (Omniclause).
Police : DejaVu Sans Mono Bold. Sprite, objets, lumière et sons : générés pour ce projet.
Le fichier `1bitDungeon.rar` de ton archive n'a pas pu être extrait ici et n'est pas utilisé. Voir `assets/licenses/`.
