extends Area2D
## Lanterne de repos : s'allume au contact et devient le point de réapparition.
const Tiles := preload("res://scripts/tiles.gd")

signal reached(pos: Vector2)

var is_on := false
var _sprite: Sprite2D
var _light: PointLight2D


func _ready() -> void:
	collision_layer = 0
	collision_mask = 2
	var cs := CollisionShape2D.new()
	var sh := RectangleShape2D.new()
	sh.size = Vector2(12, 16)
	cs.shape = sh
	add_child(cs)
	_sprite = Tiles.object_sprite(Tiles.OBJ_CP_OFF)
	add_child(_sprite)
	_light = PointLight2D.new()
	_light.texture = load("res://textures/light.png")
	_light.texture_scale = 0.45
	_light.energy = 0.0
	add_child(_light)
	body_entered.connect(_on_body_entered)


func _on_body_entered(body: Node2D) -> void:
	if is_on or not body.is_in_group("player"):
		return
	is_on = true
	Tiles.set_object_frame(_sprite, Tiles.OBJ_CP_ON)
	_light.energy = 0.7
	GameState.play_sfx("checkpoint")
	reached.emit(global_position)
