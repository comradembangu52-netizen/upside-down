extends Area2D
## Piques mortels. flip_v = true : piques tournés vers le bas (au plafond).
const Tiles := preload("res://scripts/tiles.gd")

var flip_v := false


func _ready() -> void:
	collision_layer = 0
	collision_mask = 2
	var cs := CollisionShape2D.new()
	var sh := RectangleShape2D.new()
	sh.size = Vector2(12, 8)
	cs.shape = sh
	cs.position = Vector2(0, -4.0 if flip_v else 4.0)
	add_child(cs)
	add_child(Tiles.sheet_sprite(Tiles.CELL_SPIKES, flip_v))
	body_entered.connect(_on_body_entered)


func _on_body_entered(body: Node2D) -> void:
	if body.is_in_group("player"):
		body.die()
