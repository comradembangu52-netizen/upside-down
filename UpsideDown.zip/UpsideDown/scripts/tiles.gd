extends RefCounted
## Accès aux textures et aux coordonnées de tuiles (planche 16x16 sans espacement).

const TILE := 16
const SHEET_PATH := "res://textures/tileset.png"
const OBJECTS_PATH := "res://textures/objects.png"

# Thèmes de terrain : colonnes x = [gauche, milieu A, milieu B, droite], lignes y = [haut, milieu, bas].
const THEMES := [
	{"x": [15, 16, 17, 18], "y": [5, 6, 7]},     # 0 forêt (herbe)
	{"x": [10, 11, 11, 12], "y": [5, 6, 7]},     # 1 ruines (cadre pointillé)
	{"x": [15, 16, 17, 18], "y": [12, 14, 16]},  # 2 temple (briques)
	{"x": [10, 11, 11, 12], "y": [5, 6, 7]},     # 3 profondeurs (cadre pointillé, très sombre)
]

# Indices dans objects.png
const OBJ_LEVER_OFF := 0
const OBJ_LEVER_ON := 1
const OBJ_SHARD := 2
const OBJ_CP_OFF := 3
const OBJ_CP_ON := 4
const OBJ_DOOR_PANEL := 5
const OBJ_DOOR_LOCK := 6
const OBJ_GATE_BARS := 7

# Tuiles de la planche Kenney utilisées pour les objets
const CELL_KEY := Vector2i(17, 4)
const CELL_SPIKES := Vector2i(3, 9)
const CELL_EXIT_OPEN := Vector2i(18, 2)
const CELL_EXIT_CLOSED := Vector2i(17, 2)


static func sheet() -> Texture2D:
	return load(SHEET_PATH)


static func objects() -> Texture2D:
	return load(OBJECTS_PATH)


static func sheet_sprite(cell: Vector2i, flip_v: bool = false) -> Sprite2D:
	var s := Sprite2D.new()
	s.texture = sheet()
	s.region_enabled = true
	s.region_rect = Rect2(cell.x * TILE, cell.y * TILE, TILE, TILE)
	s.flip_v = flip_v
	return s


static func object_sprite(index: int) -> Sprite2D:
	var s := Sprite2D.new()
	s.texture = objects()
	s.region_enabled = true
	s.region_rect = Rect2(index * TILE, 0, TILE, TILE)
	return s


static func set_object_frame(s: Sprite2D, index: int) -> void:
	s.region_rect = Rect2(index * TILE, 0, TILE, TILE)


static func make_area(size: Vector2, offset: Vector2 = Vector2.ZERO) -> Area2D:
	var a := Area2D.new()
	a.collision_layer = 0
	a.collision_mask = 2   # détecte uniquement le joueur
	var cs := CollisionShape2D.new()
	var sh := RectangleShape2D.new()
	sh.size = size
	cs.shape = sh
	cs.position = offset
	a.add_child(cs)
	return a
