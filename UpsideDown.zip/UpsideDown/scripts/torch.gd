extends Node2D
## Torche murale animée avec lueur vacillante.

var _light: PointLight2D
var _t := 0.0


func _ready() -> void:
	var tex: Texture2D = load("res://textures/torch.png")
	var frames := SpriteFrames.new()
	if frames.has_animation("default"):
		frames.remove_animation("default")
	frames.add_animation("burn")
	frames.set_animation_speed("burn", 8.0)
	frames.set_animation_loop("burn", true)
	for i in 8:
		var at := AtlasTexture.new()
		at.atlas = tex
		at.region = Rect2(i * 16, 0, 16, 32)
		frames.add_frame("burn", at)
	var spr := AnimatedSprite2D.new()
	spr.sprite_frames = frames
	spr.position = Vector2(0, -2)   # la vasque (haut de l'image) repose sur la case
	add_child(spr)
	spr.play("burn")
	spr.frame = randi() % 8
	_light = PointLight2D.new()
	_light.texture = load("res://textures/light.png")
	_light.texture_scale = 0.55
	_light.energy = 0.8
	_light.position = Vector2(0, -10)
	add_child(_light)


func _process(delta: float) -> void:
	_t += delta
	_light.energy = 0.75 + 0.1 * sin(_t * 9.0) + 0.05 * sin(_t * 23.0)
