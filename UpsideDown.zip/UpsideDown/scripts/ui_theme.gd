extends RefCounted
## Thème monochrome (noir / blanc) et fabriques de widgets pour tous les menus.

const FONT_PATH := "res://assets/fonts/DejaVuSansMono-Bold.ttf"


static func _box(bg: Color, border: Color, width: int = 3) -> StyleBoxFlat:
	var sb := StyleBoxFlat.new()
	sb.bg_color = bg
	sb.border_color = border
	sb.set_border_width_all(width)
	sb.set_content_margin_all(10)
	return sb


static func make_theme() -> Theme:
	var t := Theme.new()
	if ResourceLoader.exists(FONT_PATH):
		t.default_font = load(FONT_PATH)
	t.default_font_size = 24
	t.set_stylebox("normal", "Button", _box(Color.BLACK, Color.WHITE))
	t.set_stylebox("hover", "Button", _box(Color.WHITE, Color.WHITE))
	t.set_stylebox("focus", "Button", _box(Color.WHITE, Color.WHITE))
	t.set_stylebox("pressed", "Button", _box(Color(0.7, 0.7, 0.7), Color.WHITE))
	t.set_stylebox("disabled", "Button", _box(Color.BLACK, Color(0.35, 0.35, 0.35)))
	t.set_color("font_color", "Button", Color.WHITE)
	t.set_color("font_hover_color", "Button", Color.BLACK)
	t.set_color("font_focus_color", "Button", Color.BLACK)
	t.set_color("font_pressed_color", "Button", Color.BLACK)
	t.set_color("font_disabled_color", "Button", Color(0.4, 0.4, 0.4))
	t.set_color("font_color", "Label", Color.WHITE)
	t.set_stylebox("panel", "PanelContainer", _box(Color.BLACK, Color.WHITE, 4))
	return t


static func make_label(text: String, size: int = 24, color: Color = Color.WHITE) -> Label:
	var l := Label.new()
	l.text = text
	l.add_theme_font_size_override("font_size", size)
	l.add_theme_color_override("font_color", color)
	l.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	return l


static func _pressed(cb: Callable) -> void:
	GameState.play_sfx("click")
	cb.call()


static func _hover() -> void:
	GameState.play_sfx("hover", 1.0, 0.5)


static func make_button(text: String, callback: Callable, min_width: float = 360.0) -> Button:
	var b := Button.new()
	b.text = text
	b.custom_minimum_size = Vector2(min_width, 52)
	b.focus_mode = Control.FOCUS_ALL
	b.pressed.connect(_pressed.bind(callback))
	b.focus_entered.connect(_hover)
	return b


## Fond noir + poussière lumineuse qui flotte.
static func add_background(parent: Control) -> void:
	var rect := ColorRect.new()
	rect.color = Color.BLACK
	rect.mouse_filter = Control.MOUSE_FILTER_IGNORE
	parent.add_child(rect)
	rect.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	var p := CPUParticles2D.new()
	p.position = Vector2(640, 360)
	p.amount = 40
	p.lifetime = 9.0
	p.preprocess = 9.0
	p.emission_shape = CPUParticles2D.EMISSION_SHAPE_RECTANGLE
	p.emission_rect_extents = Vector2(640, 360)
	p.direction = Vector2(0, -1)
	p.spread = 180.0
	p.gravity = Vector2.ZERO
	p.initial_velocity_min = 4.0
	p.initial_velocity_max = 14.0
	p.scale_amount_min = 2.0
	p.scale_amount_max = 3.0
	p.color = Color(1, 1, 1, 0.45)
	parent.add_child(p)


## Titre + son reflet retourné (clin d'œil au concept du jeu).
static func add_title(parent: Container, text: String, size: int = 88) -> void:
	var title := make_label(text, size)
	parent.add_child(title)
	var mirror := make_label(text, size, Color(1, 1, 1, 0.16))
	mirror.rotation = PI
	mirror.resized.connect(func() -> void: mirror.pivot_offset = mirror.size * 0.5)
	parent.add_child(mirror)


static func make_center_box(parent: Control, separation: int = 14) -> VBoxContainer:
	var center := CenterContainer.new()
	parent.add_child(center)
	center.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	var box := VBoxContainer.new()
	box.add_theme_constant_override("separation", separation)
	center.add_child(box)
	return box


static func format_time(seconds: float) -> String:
	var m := int(seconds) / 60
	var s := int(seconds) % 60
	var cs := int((seconds - floorf(seconds)) * 100.0)
	return "%02d:%02d.%02d" % [m, s, cs]
