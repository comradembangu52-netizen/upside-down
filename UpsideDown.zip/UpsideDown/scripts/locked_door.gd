extends StaticBody2D
## Porte verrouillée : s'ouvre au contact si le joueur possède une clé (consommée).
const Tiles := preload("res://scripts/tiles.gd")

signal blocked

var is_open := false
var _shape: CollisionShape2D
var _sprites: Array[Sprite2D] = []
var _msg_cd := 0.0


func setup(cells: Array) -> void:
	var min_c := 99999
	var min_r := 99999
	var max_c := -1
	var max_r := -1
	for cell in cells:
		min_c = mini(min_c, cell.x)
		min_r = mini(min_r, cell.y)
		max_c = maxi(max_c, cell.x)
		max_r = maxi(max_r, cell.y)
	collision_layer = 1
	collision_mask = 0
	var size := Vector2((max_c - min_c + 1) * 16, (max_r - min_r + 1) * 16)
	var center := Vector2(min_c * 16, min_r * 16) + size * 0.5
	_shape = CollisionShape2D.new()
	var sh := RectangleShape2D.new()
	sh.size = size
	_shape.shape = sh
	_shape.position = center
	add_child(_shape)
	# Serrure sur la cellule la plus basse du milieu de la porte.
	var lock_row := max_r
	for cell in cells:
		var idx := Tiles.OBJ_DOOR_LOCK if cell.y == lock_row else Tiles.OBJ_DOOR_PANEL
		var s := Tiles.object_sprite(idx)
		s.position = Vector2(cell.x * 16 + 8, cell.y * 16 + 8)
		add_child(s)
		_sprites.append(s)
	# Capteur un peu plus large que la porte
	var sensor := Tiles.make_area(size + Vector2(6, 0), center)
	add_child(sensor)
	sensor.body_entered.connect(_on_sensor)


func _process(delta: float) -> void:
	_msg_cd = maxf(0.0, _msg_cd - delta)


func _on_sensor(body: Node2D) -> void:
	if is_open or not body.is_in_group("player"):
		return
	if body.keys > 0:
		body.keys -= 1
		is_open = true
		_shape.set_deferred("disabled", true)
		GameState.play_sfx("door")
		var tw := create_tween().set_parallel(true)
		for s in _sprites:
			tw.tween_property(s, "modulate:a", 0.0, 0.6)
		tw.chain().tween_callback(queue_free)
	elif _msg_cd <= 0.0:
		_msg_cd = 2.0
		GameState.play_sfx("blocked")
		blocked.emit()
