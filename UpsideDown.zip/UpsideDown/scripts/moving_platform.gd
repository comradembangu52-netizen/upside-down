extends AnimatableBody2D
## Plateforme mobile (aller-retour sinusoïdal, horizontal « h » ou vertical « v »).
## Le joueur est transporté automatiquement par move_and_slide().

var width_tiles := 3
var axis := "h"
var travel := 96.0      # amplitude en pixels
var speed := 0.8        # radians / seconde
var phase := 0.0
var _origin := Vector2.ZERO
var _t := 0.0


## top_left : coin haut-gauche de la plateforme en pixels (épaisseur visuelle 8 px).
func setup(top_left: Vector2) -> void:
	collision_layer = 1
	collision_mask = 0
	sync_to_physics = true
	var w := width_tiles * 16.0
	var cs := CollisionShape2D.new()
	var sh := RectangleShape2D.new()
	sh.size = Vector2(w, 8)
	cs.shape = sh
	add_child(cs)
	var tex: Texture2D = load("res://textures/platform.png")
	for i in width_tiles:
		var s := Sprite2D.new()
		s.texture = tex
		s.position = Vector2(-w * 0.5 + 8.0 + i * 16.0, 0)
		add_child(s)
	_origin = top_left + Vector2(w * 0.5, 4.0)
	position = _origin
	_t = 0.0


func _physics_process(delta: float) -> void:
	_t += delta
	var f := 0.5 - 0.5 * cos(_t * speed + phase)
	if axis == "h":
		position = _origin + Vector2(f * travel, 0.0)
	else:
		position = _origin + Vector2(0.0, -f * travel)   # « v » : monte depuis la position de départ
