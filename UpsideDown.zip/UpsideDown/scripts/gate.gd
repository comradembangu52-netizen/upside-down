extends StaticBody2D
## Grille : bloque le passage jusqu'à l'activation des leviers de même lettre.
const Tiles := preload("res://scripts/tiles.gd")

var letter := "X"
var _shape: CollisionShape2D
var _sprites: Array[Sprite2D] = []
var is_open := false


## cells : liste de Vector2i (colonne, ligne) formant un rectangle plein.
func setup(cells: Array) -> void:
	var min_c := 99999
	var min_r := 99999
	var max_c := -1
	var max_r := -1
	for cell in cells:
		min_c = mini(min_c, cell.x)
		min_r = mini(min_r, cell.y)
		max_c = maxi(max_c, cell.x)
		max_r = maxi(max_r, cell.y)
	collision_layer = 1
	collision_mask = 0
	var size := Vector2((max_c - min_c + 1) * 16, (max_r - min_r + 1) * 16)
	_shape = CollisionShape2D.new()
	var sh := RectangleShape2D.new()
	sh.size = size
	_shape.shape = sh
	_shape.position = Vector2(min_c * 16, min_r * 16) + size * 0.5
	add_child(_shape)
	for cell in cells:
		var s := Tiles.object_sprite(Tiles.OBJ_GATE_BARS)
		s.position = Vector2(cell.x * 16 + 8, cell.y * 16 + 8)
		add_child(s)
		_sprites.append(s)


func open() -> void:
	if is_open:
		return
	is_open = true
	_shape.set_deferred("disabled", true)
	GameState.play_sfx("door")
	var tw := create_tween().set_parallel(true)
	for s in _sprites:
		tw.tween_property(s, "modulate:a", 0.0, 0.6)
	tw.chain().tween_callback(queue_free)
