extends Area2D
## Éclat de lumière (niveau 5) : rallume la lanterne.
const Tiles := preload("res://scripts/tiles.gd")

signal collected


func _ready() -> void:
	collision_layer = 0
	collision_mask = 2
	var cs := CollisionShape2D.new()
	var sh := RectangleShape2D.new()
	sh.size = Vector2(12, 12)
	cs.shape = sh
	add_child(cs)
	var spr := Tiles.object_sprite(Tiles.OBJ_SHARD)
	add_child(spr)
	var light := PointLight2D.new()
	light.texture = load("res://textures/light.png")
	light.texture_scale = 0.25
	light.energy = 0.8
	add_child(light)
	var tw := create_tween().set_loops()
	tw.tween_property(spr, "position:y", -2.0, 0.6).set_trans(Tween.TRANS_SINE)
	tw.tween_property(spr, "position:y", 2.0, 0.6).set_trans(Tween.TRANS_SINE)
	body_entered.connect(_on_body_entered)


func _on_body_entered(body: Node2D) -> void:
	if body.is_in_group("player"):
		body.shards += 1
		GameState.play_sfx("pickup", 1.3)
		set_deferred("monitoring", false)
		collected.emit()
		queue_free()
