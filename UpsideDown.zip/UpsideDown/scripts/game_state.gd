extends Node
## Autoload « GameState » : progression, sauvegarde, entrées clavier, audio et transitions.

const SAVE_PATH := "user://upside_down_save.cfg"
const MAIN_MENU := "res://ui/main_menu.tscn"
const LEVEL_SELECT := "res://ui/level_select.tscn"
const OPTIONS_SCENE := "res://ui/options.tscn"
const GAME_SCENE := "res://scenes/game.tscn"
const ENDING_SCENE := "res://ui/ending.tscn"

# Les cinq niveaux (données dans levels/level_N.gd, constante DATA).
const LEVEL_SCRIPTS := [
	preload("res://levels/level_1.gd"),
	preload("res://levels/level_2.gd"),
	preload("res://levels/level_3.gd"),
	preload("res://levels/level_4.gd"),
	preload("res://levels/level_5.gd"),
]

var unlocked_level: int = 1
var current_level: int = 1
var music_volume: float = 0.7
var sfx_volume: float = 0.8
var fullscreen: bool = false
var best_times: Dictionary = {}   # "1" -> secondes

# Statistiques du dernier niveau terminé (écran de victoire).
var last_time: float = 0.0
var last_deaths: int = 0
var last_best: bool = false

var _fade_rect: ColorRect
var _changing := false
var _music: AudioStreamPlayer
var _sfx_players: Array[AudioStreamPlayer] = []
var _sfx_cache: Dictionary = {}


func _ready() -> void:
	process_mode = Node.PROCESS_MODE_ALWAYS
	_setup_inputs()
	load_progress()
	_build_fade_layer()
	_build_audio()
	apply_fullscreen()


# ---------------------------------------------------------------- niveaux
func level_count() -> int:
	return LEVEL_SCRIPTS.size()


func level_data(n: int) -> Dictionary:
	return LEVEL_SCRIPTS[clampi(n, 1, level_count()) - 1].DATA


func level_name(n: int) -> String:
	return String(level_data(n).get("name", "Niveau %d" % n))


func is_unlocked(n: int) -> bool:
	return n <= unlocked_level


func has_next_level() -> bool:
	return current_level < level_count()


func start_level(n: int) -> void:
	current_level = clampi(n, 1, level_count())
	change_scene(GAME_SCENE)


func restart_level() -> void:
	change_scene(GAME_SCENE)


func next_level() -> void:
	if has_next_level():
		start_level(current_level + 1)
	else:
		change_scene(ENDING_SCENE)


func go_to_menu() -> void:
	change_scene(MAIN_MENU)


## Appelé à la sortie d'un niveau : enregistre temps, déverrouille la suite.
func finish_level(time: float, deaths: int) -> void:
	last_time = time
	last_deaths = deaths
	var key := str(current_level)
	last_best = not best_times.has(key) or time < float(best_times[key])
	if last_best:
		best_times[key] = time
	if current_level >= unlocked_level and current_level < level_count():
		unlocked_level = current_level + 1
	save_progress()


func unlock_all() -> void:
	unlocked_level = level_count()
	save_progress()


func reset_progress() -> void:
	unlocked_level = 1
	best_times = {}
	save_progress()


# ---------------------------------------------------------------- sauvegarde
func save_progress() -> void:
	var cfg := ConfigFile.new()
	cfg.set_value("progress", "unlocked", unlocked_level)
	cfg.set_value("progress", "best_times", best_times)
	cfg.set_value("options", "music", music_volume)
	cfg.set_value("options", "sfx", sfx_volume)
	cfg.set_value("options", "fullscreen", fullscreen)
	cfg.save(SAVE_PATH)


func load_progress() -> void:
	var cfg := ConfigFile.new()
	if cfg.load(SAVE_PATH) != OK:
		return
	unlocked_level = clampi(int(cfg.get_value("progress", "unlocked", 1)), 1, level_count())
	best_times = cfg.get_value("progress", "best_times", {})
	music_volume = clampf(float(cfg.get_value("options", "music", 0.7)), 0.0, 1.0)
	sfx_volume = clampf(float(cfg.get_value("options", "sfx", 0.8)), 0.0, 1.0)
	fullscreen = bool(cfg.get_value("options", "fullscreen", false))


# ---------------------------------------------------------------- options
func apply_fullscreen() -> void:
	if fullscreen:
		DisplayServer.window_set_mode(DisplayServer.WINDOW_MODE_FULLSCREEN)
	else:
		DisplayServer.window_set_mode(DisplayServer.WINDOW_MODE_WINDOWED)


func set_music_volume(v: float) -> void:
	music_volume = clampf(v, 0.0, 1.0)
	_apply_music_volume()
	save_progress()


func set_sfx_volume(v: float) -> void:
	sfx_volume = clampf(v, 0.0, 1.0)
	save_progress()


func set_fullscreen(on: bool) -> void:
	fullscreen = on
	apply_fullscreen()
	save_progress()


# ---------------------------------------------------------------- entrées
func _setup_inputs() -> void:
	# keycode (et non physical_keycode) : la touche « A » reste la touche étiquetée A en AZERTY.
	_add_action("move_left", [KEY_LEFT, KEY_A, KEY_Q])
	_add_action("move_right", [KEY_RIGHT, KEY_D])
	_add_action("jump", [KEY_SPACE, KEY_UP])
	_add_action("flip", [KEY_SHIFT])
	_add_action("pause", [KEY_ESCAPE])
	_add_action("restart", [KEY_R])


func _add_action(action: String, keys: Array) -> void:
	if not InputMap.has_action(action):
		InputMap.add_action(action)
	for k in keys:
		var ev := InputEventKey.new()
		ev.keycode = k
		InputMap.action_add_event(action, ev)


# ---------------------------------------------------------------- audio
func _build_audio() -> void:
	for i in 8:
		var p := AudioStreamPlayer.new()
		add_child(p)
		_sfx_players.append(p)
	_music = AudioStreamPlayer.new()
	add_child(_music)
	var stream := _get_stream("ambience")
	if stream != null:
		_music.stream = stream
		_music.finished.connect(_music.play)
		_apply_music_volume()
		_music.play()


func _apply_music_volume() -> void:
	if _music != null:
		_music.volume_db = linear_to_db(maxf(music_volume * 0.6, 0.0001))


func _get_stream(sfx_name: String) -> AudioStream:
	if _sfx_cache.has(sfx_name):
		return _sfx_cache[sfx_name]
	var path := "res://audio/%s.wav" % sfx_name
	var stream: AudioStream = null
	if ResourceLoader.exists(path):
		stream = load(path)
	_sfx_cache[sfx_name] = stream
	return stream


func play_sfx(sfx_name: String, pitch: float = 1.0, volume_scale: float = 1.0) -> void:
	var stream := _get_stream(sfx_name)
	if stream == null:
		return
	for p in _sfx_players:
		if not p.playing:
			p.stream = stream
			p.pitch_scale = pitch
			p.volume_db = linear_to_db(clampf(sfx_volume * volume_scale, 0.0001, 1.0))
			p.play()
			return


# ---------------------------------------------------------------- transitions
func _build_fade_layer() -> void:
	var layer := CanvasLayer.new()
	layer.layer = 100
	add_child(layer)
	_fade_rect = ColorRect.new()
	_fade_rect.color = Color(0, 0, 0, 0)
	_fade_rect.mouse_filter = Control.MOUSE_FILTER_IGNORE
	layer.add_child(_fade_rect)
	_fade_rect.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)


func change_scene(path: String) -> void:
	if _changing:
		return
	_changing = true
	_fade_rect.mouse_filter = Control.MOUSE_FILTER_STOP
	var tw := create_tween()
	tw.tween_property(_fade_rect, "color:a", 1.0, 0.22)
	await tw.finished
	get_tree().paused = false
	get_tree().change_scene_to_file(path)
	await get_tree().process_frame
	await get_tree().process_frame
	var tw2 := create_tween()
	tw2.tween_property(_fade_rect, "color:a", 0.0, 0.25)
	await tw2.finished
	_fade_rect.mouse_filter = Control.MOUSE_FILTER_IGNORE
	_changing = false


func quit_game() -> void:
	save_progress()
	get_tree().quit()
