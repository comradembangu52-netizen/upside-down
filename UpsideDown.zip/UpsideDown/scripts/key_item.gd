extends Area2D
## Clé flottante : ouvre une porte verrouillée.
const Tiles := preload("res://scripts/tiles.gd")


func _ready() -> void:
	collision_layer = 0
	collision_mask = 2
	var cs := CollisionShape2D.new()
	var sh := RectangleShape2D.new()
	sh.size = Vector2(12, 12)
	cs.shape = sh
	add_child(cs)
	var spr := Tiles.sheet_sprite(Tiles.CELL_KEY)
	add_child(spr)
	var tw := create_tween().set_loops()
	tw.tween_property(spr, "position:y", -2.0, 0.7).set_trans(Tween.TRANS_SINE)
	tw.tween_property(spr, "position:y", 2.0, 0.7).set_trans(Tween.TRANS_SINE)
	body_entered.connect(_on_body_entered)


func _on_body_entered(body: Node2D) -> void:
	if body.is_in_group("player"):
		body.keys += 1
		GameState.play_sfx("pickup")
		set_deferred("monitoring", false)
		queue_free()
