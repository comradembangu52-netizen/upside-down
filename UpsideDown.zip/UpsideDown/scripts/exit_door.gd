extends Area2D
## Porte de sortie. Si required_shards > 0, elle reste close tant que tous les éclats ne sont pas réunis.
const Tiles := preload("res://scripts/tiles.gd")

signal reached
signal blocked

var required_shards := 0
var is_open := true
var _sprite: Sprite2D
var _msg_cd := 0.0


func _ready() -> void:
	collision_layer = 0
	collision_mask = 2
	var cs := CollisionShape2D.new()
	var sh := RectangleShape2D.new()
	sh.size = Vector2(10, 14)
	cs.shape = sh
	add_child(cs)
	is_open = required_shards == 0
	_sprite = Tiles.sheet_sprite(Tiles.CELL_EXIT_OPEN if is_open else Tiles.CELL_EXIT_CLOSED)
	add_child(_sprite)
	var light := PointLight2D.new()
	light.texture = load("res://textures/light.png")
	light.texture_scale = 0.5
	light.energy = 0.6
	add_child(light)
	body_entered.connect(_on_body_entered)


func _process(delta: float) -> void:
	_msg_cd = maxf(0.0, _msg_cd - delta)


## Appelé quand le nombre d'éclats change.
func refresh(shards: int) -> void:
	if not is_open and shards >= required_shards:
		is_open = true
		_sprite.region_rect = Rect2(Tiles.CELL_EXIT_OPEN.x * 16, Tiles.CELL_EXIT_OPEN.y * 16, 16, 16)
		GameState.play_sfx("door")


func _on_body_entered(body: Node2D) -> void:
	if not body.is_in_group("player"):
		return
	if is_open:
		reached.emit()
	elif _msg_cd <= 0.0:
		_msg_cd = 2.0
		GameState.play_sfx("blocked")
		blocked.emit()
