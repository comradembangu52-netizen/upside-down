extends CharacterBody2D
## Petit explorateur à lanterne. SHIFT retourne le monde : la gravité s'inverse.
## Le joueur n'est jamais pivoté : seul son sprite suit la rotation de la caméra
## pour rester visuellement droit.

signal flipped(is_flipped: bool)
signal died

const SPEED := 110.0
const ACCEL := 1100.0
const AIR_ACCEL := 750.0
const FRICTION := 1300.0
const GRAVITY := 850.0
const MAX_FALL := 380.0
const JUMP_SPEED := 300.0
const JUMP_CUT := 0.45
const COYOTE_TIME := 0.10
const JUMP_BUFFER := 0.12
const FLIP_COOLDOWN := 0.65

var gravity_dir: float = 1.0      # +1 = normal, -1 = monde retourné
var is_flipped := false
var controls_enabled := true
var dead := false
var keys := 0
var shards := 0
var kill_min_y := -96.0
var kill_max_y := 400.0
var light_factor := 1.0           # 1 = pleine lumière (le niveau 5 la fait baisser)

var _light_base := 1.0
var _coyote := 0.0
var _jump_buffer := 0.0
var _flip_cd := 0.0
var _land_timer := 0.0
var _facing := 1                  # sens à l'écran : 1 = droite, -1 = gauche
var _was_on_floor := false
var _time := 0.0

@onready var sprite: AnimatedSprite2D = $Sprite
@onready var lantern: PointLight2D = $Lantern
@onready var dust: CPUParticles2D = $Dust
@onready var burst: CPUParticles2D = $Burst


func _ready() -> void:
	add_to_group("player")
	collision_layer = 2
	collision_mask = 1
	up_direction = Vector2.UP
	floor_snap_length = 3.0
	_build_frames()
	sprite.play("idle")
	lantern.texture = load("res://textures/light.png")
	lantern.shadow_enabled = false


func set_light_scale(s: float) -> void:
	_light_base = s


func _build_frames() -> void:
	var tex: Texture2D = load("res://textures/player.png")
	var frames := SpriteFrames.new()
	# nom, indices dans la planche, vitesse, boucle
	var defs := [
		["idle", [0, 1], 2.5, true],
		["walk", [2, 3, 4, 5], 9.0, true],
		["jump", [6], 1.0, false],
		["fall", [7], 1.0, false],
		["land", [8, 9], 14.0, false],
	]
	if frames.has_animation("default"):
		frames.remove_animation("default")
	for d in defs:
		var anim_name: String = d[0]
		frames.add_animation(anim_name)
		frames.set_animation_speed(anim_name, d[2])
		frames.set_animation_loop(anim_name, d[3])
		for idx in d[1]:
			var at := AtlasTexture.new()
			at.atlas = tex
			at.region = Rect2(idx * 16, 0, 16, 16)
			frames.add_frame(anim_name, at)
	sprite.sprite_frames = frames


func _physics_process(delta: float) -> void:
	_time += delta
	_update_visuals(delta)
	if dead:
		return
	_flip_cd = maxf(0.0, _flip_cd - delta)
	_land_timer = maxf(0.0, _land_timer - delta)
	var on_floor := is_on_floor()
	if on_floor:
		_coyote = COYOTE_TIME
	else:
		_coyote = maxf(0.0, _coyote - delta)
	_jump_buffer = maxf(0.0, _jump_buffer - delta)

	var axis := 0.0
	if controls_enabled:
		axis = Input.get_axis("move_left", "move_right")
		if Input.is_action_just_pressed("jump"):
			_jump_buffer = JUMP_BUFFER
		if Input.is_action_just_pressed("flip"):
			try_flip()

	# Dans le monde retourné, la droite de l'écran correspond à -x dans le monde.
	var view_sign := -1.0 if is_flipped else 1.0
	if axis != 0.0:
		var accel := ACCEL if on_floor else AIR_ACCEL
		velocity.x = move_toward(velocity.x, axis * view_sign * SPEED, accel * delta)
		_facing = 1 if axis > 0.0 else -1
	else:
		var fr := FRICTION if on_floor else AIR_ACCEL * 0.5
		velocity.x = move_toward(velocity.x, 0.0, fr * delta)

	# Gravité (signée) + chute limitée
	velocity.y += GRAVITY * gravity_dir * delta
	velocity.y = clampf(velocity.y, -MAX_FALL, MAX_FALL)

	# Saut (tampon + temps de grâce) : le saut va toujours « vers le haut de l'écran ».
	if controls_enabled and _jump_buffer > 0.0 and _coyote > 0.0:
		velocity.y = -JUMP_SPEED * gravity_dir
		_jump_buffer = 0.0
		_coyote = 0.0
		GameState.play_sfx("jump")
	# Saut variable : relâcher la touche raccourcit le saut.
	if controls_enabled and Input.is_action_just_released("jump") and velocity.y * gravity_dir < 0.0:
		velocity.y *= JUMP_CUT

	var fall_speed := velocity.y * gravity_dir   # > 0 : on tombe vers le « sol » courant
	move_and_slide()

	# Atterrissage
	var now_on_floor := is_on_floor()
	if now_on_floor and not _was_on_floor and fall_speed > 140.0:
		_land_timer = 0.14
		GameState.play_sfx("land", 1.0, 0.6)
		_emit_dust()
	_was_on_floor = now_on_floor

	if global_position.y > kill_max_y or global_position.y < kill_min_y:
		die()


## Inverse le monde (SHIFT). Retourne true si l'inversion a eu lieu.
func try_flip() -> bool:
	if dead or not controls_enabled or _flip_cd > 0.0:
		return false
	is_flipped = not is_flipped
	gravity_dir = -1.0 if is_flipped else 1.0
	up_direction = Vector2(0.0, -gravity_dir)
	velocity.y *= 0.25
	_flip_cd = FLIP_COOLDOWN
	GameState.play_sfx("flip")
	flipped.emit(is_flipped)
	return true


func flip_ready() -> bool:
	return _flip_cd <= 0.0 and not dead


func _update_visuals(_delta: float) -> void:
	var cam := get_viewport().get_camera_2d()
	var rot := cam.global_rotation if cam != null else 0.0
	# Le sprite suit la caméra : il reste droit à l'écran, même monde retourné.
	sprite.global_rotation = rot
	sprite.flip_h = _facing < 0
	lantern.position = Vector2(_facing * 5.0, 1.0).rotated(rot)
	var flick := 1.0 + 0.04 * sin(_time * 11.0) + 0.03 * sin(_time * 5.3)
	lantern.texture_scale = _light_base * light_factor * flick
	if dead:
		return
	var anim := "idle"
	if not is_on_floor():
		anim = "jump" if velocity.y * gravity_dir < 0.0 else "fall"
	elif _land_timer > 0.0:
		anim = "land"
	elif absf(velocity.x) > 12.0:
		anim = "walk"
	if sprite.animation != anim:
		sprite.play(anim)


func _emit_dust() -> void:
	dust.position = Vector2(0, 8.0 * gravity_dir)
	dust.direction = Vector2(0, -gravity_dir)
	dust.restart()
	dust.emitting = true


func die() -> void:
	if dead:
		return
	dead = true
	velocity = Vector2.ZERO
	sprite.hide()
	burst.restart()
	burst.emitting = true
	GameState.play_sfx("death")
	died.emit()


## Réapparition au dernier checkpoint, toujours monde à l'endroit.
func respawn(pos: Vector2) -> void:
	global_position = pos
	velocity = Vector2.ZERO
	is_flipped = false
	gravity_dir = 1.0
	up_direction = Vector2.UP
	dead = false
	controls_enabled = true
	_flip_cd = 0.3
	_coyote = 0.0
	_jump_buffer = 0.0
	sprite.show()
	sprite.play("idle")
