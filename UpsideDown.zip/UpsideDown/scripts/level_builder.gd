extends Node2D
## Construit un niveau à partir de sa description (levels/level_N.gd) :
## terrain dessiné + collisions fusionnées + objets interactifs + décor.

signal exit_reached
signal checkpoint_reached(pos: Vector2)
signal shard_collected(count: int, total: int)
signal message(text: String)

const TILE := 16
const Tiles := preload("res://scripts/tiles.gd")
const TerrainView := preload("res://scripts/terrain_view.gd")

var cols := 0
var rows := 0
var pixel_size := Vector2.ZERO
var spawn_position := Vector2.ZERO
var shards_total := 0
var shards_got := 0

var _grid: Array[String] = []
var _theme: Dictionary = {}
var _gates: Dictionary = {}        # lettre -> Array de gates
var _lever_total: Dictionary = {}  # lettre -> nombre de leviers
var _lever_on: Dictionary = {}     # lettre -> leviers actifs
var _exit: Node = null
var _required_shards := 0

var _scene_cache: Dictionary = {}


func build(data: Dictionary) -> void:
	_theme = Tiles.THEMES[clampi(int(data.get("theme", 0)), 0, Tiles.THEMES.size() - 1)]
	_required_shards = int(data.get("required_shards", 0))
	for row in data["map"]:
		_grid.append(String(row))
	rows = _grid.size()
	for row in _grid:
		cols = maxi(cols, row.length())
	pixel_size = Vector2(cols * TILE, rows * TILE)
	_build_visuals()
	_build_collision()
	_spawn_entities()
	_spawn_groups()
	_spawn_movers(data.get("movers", []))
	# Léviers : on compte combien il y en a par lettre
	shards_total = _count_char("o")


# ------------------------------------------------------------------ utilitaires
func _cell(c: int, r: int) -> String:
	if r < 0 or r >= rows:
		return "#"
	var row: String = _grid[r]
	if c < 0 or c >= row.length():
		return "#" if (c < 0 or c >= cols) else "."
	return row[c]


func _is_solid(c: int, r: int) -> bool:
	return _cell(c, r) == "#"


func _count_char(ch: String) -> int:
	var n := 0
	for row in _grid:
		n += row.count(ch)
	return n


func _scene(path: String) -> PackedScene:
	if not _scene_cache.has(path):
		_scene_cache[path] = load(path)
	return _scene_cache[path]


func _instance(name_: String) -> Node:
	return _scene("res://scenes/objects/%s.tscn" % name_).instantiate()


func _center(c: int, r: int) -> Vector2:
	return Vector2(c * TILE + TILE * 0.5, r * TILE + TILE * 0.5)


# ------------------------------------------------------------------ visuel
func _build_visuals() -> void:
	var tex := Tiles.sheet()
	var decor := TerrainView.new()
	decor.texture = tex
	decor.z_index = -3
	var terrain := TerrainView.new()
	terrain.texture = tex
	terrain.z_index = -2
	for r in rows:
		for c in cols:
			var ch := _cell(c, r)
			if ch == "#":
				_add_terrain_tile(terrain, c, r)
			else:
				_add_decor(decor, ch, c, r)
	add_child(decor)
	add_child(terrain)


func _src(cell_x: int, cell_y: int) -> Rect2:
	return Rect2(cell_x * TILE, cell_y * TILE, TILE, TILE)


func _add_terrain_tile(t: Node2D, c: int, r: int) -> void:
	var xs: Array = _theme["x"]
	var ys: Array = _theme["y"]
	var up := not _is_solid(c, r - 1)
	var down := not _is_solid(c, r + 1)
	var left := not _is_solid(c - 1, r)
	var right := not _is_solid(c + 1, r)
	var col_i := 1 + ((c * 7 + r * 3) % 2)
	if left:
		col_i = 0
	elif right:
		col_i = 3
	var row_i := 1
	var flip := false
	if up:
		row_i = 0
	elif down:
		row_i = 0
		flip = true
	var dst := Rect2(c * TILE, r * TILE, TILE, TILE)
	t.add(_src(xs[col_i], ys[row_i]), dst, flip)
	# Plateforme fine (surface en haut ET en bas) : on ajoute la bordure inférieure.
	if up and down:
		var strip_src := Rect2(xs[col_i] * TILE, ys[0] * TILE, TILE, 5)
		t.add(strip_src, Rect2(c * TILE, r * TILE + TILE - 5, TILE, 5), true)
	# Mur fin (surface à gauche ET à droite) : on ajoute la bordure droite.
	if left and right:
		var strip := Rect2(xs[3] * TILE + 11, ys[row_i] * TILE, 5, TILE)
		t.add(strip, Rect2(c * TILE + 11, r * TILE, 5, TILE), false)


func _add_decor(t: Node2D, ch: String, c: int, r: int) -> void:
	match ch:
		"T":   # pin : 3 tuiles de haut
			for i in 3:
				t.add(_src(15, i), Rect2(c * TILE, (r - 2 + i) * TILE, TILE, TILE))
		"R":   # arbre rond : 2 tuiles
			for i in 2:
				t.add(_src(14, i), Rect2(c * TILE, (r - 1 + i) * TILE, TILE, TILE))
		"g":
			t.add(_src(18, 1), Rect2(c * TILE, r * TILE, TILE, TILE))
		"f":
			t.add(_src(17, 0), Rect2(c * TILE, r * TILE, TILE, TILE))
		"u":   # liane qui pend
			for i in 2:
				t.add(_src(19, i), Rect2(c * TILE, (r + i) * TILE, TILE, TILE))
		"h":   # chaîne + lanterne suspendue
			for i in 3:
				t.add(_src(3, i), Rect2(c * TILE, (r + i) * TILE, TILE, TILE))
		"m":
			t.add(_src(14, 2), Rect2(c * TILE, r * TILE, TILE, TILE))
		"s":   # stalactites
			t.add(_src(6, 8), Rect2(c * TILE, r * TILE, TILE, TILE))
		"A":
			t.add(_src(13, 3), Rect2(c * TILE, r * TILE, TILE, TILE))
		"a":
			t.add(_src(12, 3), Rect2(c * TILE, r * TILE, TILE, TILE))
		"!":
			t.add(_src(17, 3), Rect2(c * TILE, r * TILE, TILE, TILE))
		"c":   # colonne (pack Ruins) : 16x48 posée sur la case
			var s := Sprite2D.new()
			s.texture = load("res://textures/column.png")
			s.centered = false
			s.position = Vector2(c * TILE, (r - 2) * TILE)
			s.z_index = -3
			add_child(s)


# ------------------------------------------------------------------ collisions
func _build_collision() -> void:
	var body := StaticBody2D.new()
	body.collision_layer = 1
	body.collision_mask = 0
	add_child(body)
	var used := {}
	for r in rows:
		var c := 0
		while c < cols:
			if _is_solid(c, r) and not used.has(Vector2i(c, r)):
				var c1 := c
				while c1 + 1 < cols and _is_solid(c1 + 1, r) and not used.has(Vector2i(c1 + 1, r)):
					c1 += 1
				var r1 := r
				while r1 + 1 < rows and _row_full(c, c1, r1 + 1, used):
					r1 += 1
				for rr in range(r, r1 + 1):
					for cc in range(c, c1 + 1):
						used[Vector2i(cc, rr)] = true
				var cs := CollisionShape2D.new()
				var sh := RectangleShape2D.new()
				sh.size = Vector2((c1 - c + 1) * TILE, (r1 - r + 1) * TILE)
				cs.shape = sh
				cs.position = Vector2(c * TILE, r * TILE) + sh.size * 0.5
				body.add_child(cs)
				c = c1 + 1
			else:
				c += 1


func _row_full(c0: int, c1: int, r: int, used: Dictionary) -> bool:
	for cc in range(c0, c1 + 1):
		if not _is_solid(cc, r) or used.has(Vector2i(cc, r)):
			return false
	return true


# ------------------------------------------------------------------ entités
func _spawn_entities() -> void:
	for r in rows:
		for c in cols:
			var ch := _cell(c, r)
			var pos := _center(c, r)
			match ch:
				"P":
					spawn_position = pos
				"E":
					var e: Area2D = _instance("exit_door")
					e.required_shards = _required_shards
					e.position = pos
					add_child(e)
					e.reached.connect(func() -> void: exit_reached.emit())
					e.blocked.connect(func() -> void: message.emit("L'autel attend les trois éclats de lumière."))
					_exit = e
				"C":
					var cp: Area2D = _instance("checkpoint")
					cp.position = pos
					add_child(cp)
					cp.reached.connect(func(p: Vector2) -> void: checkpoint_reached.emit(p))
				"^", "V":
					var sp: Area2D = _instance("spike")
					sp.flip_v = (ch == "V")
					sp.position = pos
					add_child(sp)
				"K":
					var k: Area2D = _instance("key_item")
					k.position = pos
					add_child(k)
				"o":
					var s: Area2D = _instance("shard")
					s.position = pos
					add_child(s)
					s.collected.connect(_on_shard_collected)
				"x", "y", "z":
					var lv: Area2D = _instance("lever")
					lv.letter = ch.to_upper()
					lv.position = pos
					add_child(lv)
					_lever_total[lv.letter] = int(_lever_total.get(lv.letter, 0)) + 1
					lv.activated.connect(_on_lever_activated)
				"w":
					var tch: Node2D = _instance("torch")
					tch.position = pos
					tch.z_index = -1
					add_child(tch)


func _on_shard_collected() -> void:
	shards_got += 1
	if _exit != null:
		_exit.refresh(shards_got)
	shard_collected.emit(shards_got, shards_total)


func _on_lever_activated(letter: String) -> void:
	_lever_on[letter] = int(_lever_on.get(letter, 0)) + 1
	if _lever_on[letter] >= int(_lever_total.get(letter, 1)):
		message.emit("Un mécanisme s'est déclenché…")
		for g in _gates.get(letter, []):
			if is_instance_valid(g):
				g.open()
	else:
		message.emit("Levier activé (%d/%d)" % [_lever_on[letter], _lever_total[letter]])


## Regroupe les cases connexes de portes (D) et de grilles (X, Y, Z).
func _spawn_groups() -> void:
	var visited := {}
	for r in rows:
		for c in cols:
			var ch := _cell(c, r)
			if ch not in ["D", "X", "Y", "Z"] or visited.has(Vector2i(c, r)):
				continue
			var cells := _flood(c, r, ch, visited)
			if ch == "D":
				var d: StaticBody2D = _instance("locked_door")
				add_child(d)
				d.setup(cells)
				d.blocked.connect(func() -> void: message.emit("Cette porte est verrouillée : il faut une clé."))
			else:
				var g: StaticBody2D = _instance("gate")
				g.letter = ch
				add_child(g)
				g.setup(cells)
				if not _gates.has(ch):
					_gates[ch] = []
				_gates[ch].append(g)


func _flood(c: int, r: int, ch: String, visited: Dictionary) -> Array:
	var out: Array = []
	var stack: Array = [Vector2i(c, r)]
	while not stack.is_empty():
		var p: Vector2i = stack.pop_back()
		if visited.has(p) or _cell(p.x, p.y) != ch:
			continue
		visited[p] = true
		out.append(p)
		stack.append(Vector2i(p.x + 1, p.y))
		stack.append(Vector2i(p.x - 1, p.y))
		stack.append(Vector2i(p.x, p.y + 1))
		stack.append(Vector2i(p.x, p.y - 1))
	return out


func _spawn_movers(list: Array) -> void:
	for m in list:
		var p: AnimatableBody2D = _instance("moving_platform")
		p.width_tiles = int(m["w"])
		p.axis = String(m["axis"])
		p.travel = float(m["range"]) * TILE
		p.speed = float(m["speed"])
		p.phase = float(m["phase"])
		add_child(p)
		p.setup(Vector2(int(m["x"]) * TILE, int(m["y"]) * TILE))
