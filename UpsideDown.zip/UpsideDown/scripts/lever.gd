extends Area2D
## Levier : s'active au contact (définitivement). Ouvre les grilles de même lettre.
const Tiles := preload("res://scripts/tiles.gd")

signal activated(letter: String)

var letter := "x"
var is_on := false
var _sprite: Sprite2D


func _ready() -> void:
	collision_layer = 0
	collision_mask = 2
	var cs := CollisionShape2D.new()
	var sh := RectangleShape2D.new()
	sh.size = Vector2(12, 14)
	cs.shape = sh
	add_child(cs)
	_sprite = Tiles.object_sprite(Tiles.OBJ_LEVER_OFF)
	add_child(_sprite)
	body_entered.connect(_on_body_entered)


func _on_body_entered(body: Node2D) -> void:
	if is_on or not body.is_in_group("player"):
		return
	is_on = true
	Tiles.set_object_frame(_sprite, Tiles.OBJ_LEVER_ON)
	GameState.play_sfx("lever")
	activated.emit(letter)
