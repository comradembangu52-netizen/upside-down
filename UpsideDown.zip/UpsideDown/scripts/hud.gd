extends CanvasLayer
## Interface en jeu : nom du niveau, clés, éclats, temps, indicateur MAJ, indices, messages.
const UITheme := preload("res://scripts/ui_theme.gd")

var _name_label: Label
var _status_label: Label
var _hint_label: Label
var _msg_label: Label
var _intro_title: Label
var _intro_sub: Label
var _msg_tween: Tween
var _hint_text := ""


func _ready() -> void:
	layer = 10
	var root := Control.new()
	root.theme = UITheme.make_theme()
	root.mouse_filter = Control.MOUSE_FILTER_IGNORE
	add_child(root)
	root.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)

	_name_label = UITheme.make_label("", 20, Color(0.8, 0.8, 0.8))
	_name_label.position = Vector2(24, 14)
	root.add_child(_name_label)

	_status_label = UITheme.make_label("", 20)
	_status_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_RIGHT
	root.add_child(_status_label)
	_status_label.set_anchors_and_offsets_preset(Control.PRESET_TOP_RIGHT)
	_status_label.offset_left = -520
	_status_label.offset_right = -24
	_status_label.offset_top = 14

	_hint_label = UITheme.make_label("", 26)
	root.add_child(_hint_label)
	_hint_label.set_anchors_and_offsets_preset(Control.PRESET_BOTTOM_WIDE)
	_hint_label.offset_top = -64
	_hint_label.offset_bottom = -20
	_hint_label.modulate.a = 0.0

	_msg_label = UITheme.make_label("", 24)
	root.add_child(_msg_label)
	_msg_label.set_anchors_and_offsets_preset(Control.PRESET_CENTER_TOP)
	_msg_label.offset_left = -400
	_msg_label.offset_right = 400
	_msg_label.offset_top = 70
	_msg_label.modulate.a = 0.0

	_intro_title = UITheme.make_label("", 56)
	root.add_child(_intro_title)
	_intro_title.set_anchors_and_offsets_preset(Control.PRESET_CENTER)
	_intro_title.offset_left = -600
	_intro_title.offset_right = 600
	_intro_title.offset_top = -80
	_intro_title.offset_bottom = -10
	_intro_sub = UITheme.make_label("", 26, Color(0.75, 0.75, 0.75))
	root.add_child(_intro_sub)
	_intro_sub.set_anchors_and_offsets_preset(Control.PRESET_CENTER)
	_intro_sub.offset_left = -600
	_intro_sub.offset_right = 600
	_intro_sub.offset_top = 0
	_intro_sub.offset_bottom = 50


func show_intro(level_number: int, title: String, subtitle: String) -> void:
	_name_label.text = "%d - %s" % [level_number, title.to_upper()]
	_intro_title.text = title
	_intro_sub.text = subtitle
	_intro_title.modulate.a = 0.0
	_intro_sub.modulate.a = 0.0
	var tw := create_tween()
	tw.tween_property(_intro_title, "modulate:a", 1.0, 0.5)
	tw.parallel().tween_property(_intro_sub, "modulate:a", 1.0, 0.5)
	tw.tween_interval(1.8)
	tw.tween_property(_intro_title, "modulate:a", 0.0, 0.8)
	tw.parallel().tween_property(_intro_sub, "modulate:a", 0.0, 0.8)


func update_state(keys: int, shards: int, shards_total: int, time: float, flip_ready: bool) -> void:
	var parts: Array[String] = []
	if keys > 0:
		parts.append("CLÉS %d" % keys)
	if shards_total > 0:
		parts.append("ÉCLATS %d/%d" % [shards, shards_total])
	parts.append(UITheme.format_time(time))
	parts.append("MAJ " + ("PRÊT" if flip_ready else "..."))
	_status_label.text = "   ".join(parts)


func set_hint(text: String) -> void:
	if text == _hint_text:
		return
	_hint_text = text
	if text != "":
		_hint_label.text = text
	var tw := create_tween()
	tw.tween_property(_hint_label, "modulate:a", 1.0 if text != "" else 0.0, 0.3)


func show_message(text: String) -> void:
	_msg_label.text = text
	if _msg_tween != null:
		_msg_tween.kill()
	_msg_label.modulate.a = 1.0
	_msg_tween = create_tween()
	_msg_tween.tween_interval(2.2)
	_msg_tween.tween_property(_msg_label, "modulate:a", 0.0, 0.6)
