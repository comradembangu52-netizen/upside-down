extends Node2D
## Scène de jeu : construit le niveau, suit le joueur avec la caméra, fait pivoter
## le monde à 180° quand le joueur inverse la gravité, gère pause / mort / victoire.

const TILE := 16
const FLIP_TIME := 0.5
const LevelBuilder := preload("res://scripts/level_builder.gd")

@onready var world: Node2D = $World
@onready var camera: Camera2D = $Camera
@onready var darkness: CanvasModulate = $Darkness
@onready var hud = $Hud
@onready var pause_menu = $PauseMenu
@onready var victory = $VictoryScreen

var data: Dictionary
var builder: Node2D
var player: CharacterBody2D
var checkpoint_pos := Vector2.ZERO
var elapsed := 0.0
var deaths := 0

var _finished := false
var _rot_tween: Tween
var _light_reset_time := 0.0
var _fade_light := false


func _ready() -> void:
	data = GameState.level_data(GameState.current_level)
	_fade_light = bool(data.get("fade_light", false))

	builder = LevelBuilder.new()
	world.add_child(builder)
	builder.build(data)
	builder.exit_reached.connect(_on_exit_reached)
	builder.checkpoint_reached.connect(func(p: Vector2) -> void: checkpoint_pos = p)
	builder.shard_collected.connect(_on_shard_collected)
	builder.message.connect(hud.show_message)

	var player_scene: PackedScene = load("res://scenes/player.tscn")
	player = player_scene.instantiate()
	world.add_child(player)
	player.global_position = builder.spawn_position
	checkpoint_pos = builder.spawn_position
	player.kill_max_y = builder.pixel_size.y + 64.0
	player.kill_min_y = -96.0
	player.set_light_scale(float(data.get("light", 1.0)))
	player.flipped.connect(_on_player_flipped)
	player.died.connect(_on_player_died)

	var a := float(data.get("ambient", 0.1))
	darkness.color = Color(a, a, a, 1.0)

	camera.ignore_rotation = false
	camera.position_smoothing_enabled = false
	camera.enabled = true
	_update_camera(1.0, true)
	camera.make_current()

	hud.show_intro(GameState.current_level, String(data.get("name", "")), String(data.get("subtitle", "")))


func _process(delta: float) -> void:
	if get_tree().paused:
		return
	if not _finished:
		elapsed += delta
	_update_camera(delta, false)
	if _fade_light:
		var t := clampf((elapsed - _light_reset_time) / 120.0, 0.0, 1.0)
		player.light_factor = 1.0 - 0.45 * t
	var col := int(player.global_position.x / TILE)
	var hint := ""
	for h in data.get("hints", []):
		if col >= int(h[0]) and col <= int(h[1]):
			hint = String(h[2])
	hud.set_hint(hint)
	hud.update_state(player.keys, player.shards, builder.shards_total, elapsed, player.flip_ready())


func _update_camera(delta: float, snap: bool) -> void:
	var vp: Vector2 = get_viewport_rect().size
	var level_size: Vector2 = builder.pixel_size
	# Zoom : la hauteur totale du niveau tient exactement dans la fenêtre.
	var zoom: float = vp.y / level_size.y
	camera.zoom = Vector2(zoom, zoom)
	var half_w: float = vp.x / zoom * 0.5
	var target_x: float = player.global_position.x
	if level_size.x <= half_w * 2.0:
		target_x = level_size.x * 0.5
	else:
		target_x = clampf(target_x, half_w, level_size.x - half_w)
	var k: float = 1.0 if snap else 1.0 - exp(-8.0 * delta)
	camera.position.x = lerpf(camera.position.x, target_x, k)
	camera.position.y = level_size.y * 0.5


func _on_player_flipped(is_flipped: bool) -> void:
	if _rot_tween != null:
		_rot_tween.kill()
	_rot_tween = create_tween()
	var target := PI if is_flipped else 0.0
	_rot_tween.tween_property(camera, "rotation", target, FLIP_TIME).set_trans(Tween.TRANS_SINE).set_ease(Tween.EASE_IN_OUT)


func _on_player_died() -> void:
	deaths += 1
	await get_tree().create_timer(0.7).timeout
	if _finished:
		return
	if _rot_tween != null:
		_rot_tween.kill()
	camera.rotation = 0.0
	player.respawn(checkpoint_pos)


func _on_shard_collected(_count: int, _total: int) -> void:
	_light_reset_time = elapsed
	hud.show_message("Éclat de lumière récupéré !")


func _on_exit_reached() -> void:
	if _finished:
		return
	_finished = true
	player.controls_enabled = false
	GameState.play_sfx("win")
	GameState.finish_level(elapsed, deaths)
	await get_tree().create_timer(0.7).timeout
	victory.open(elapsed, deaths, GameState.has_next_level())


func _unhandled_input(event: InputEvent) -> void:
	if _finished:
		return
	if event.is_action_pressed("pause"):
		pause_menu.open()
		get_viewport().set_input_as_handled()
	elif event.is_action_pressed("restart"):
		GameState.restart_level()
