extends Node2D
## Dessine d'un seul coup toutes les tuiles d'un calque (1 seul CanvasItem = léger).

var texture: Texture2D
var _ops: Array = []   # [src: Rect2, dst: Rect2, flip_v: bool]


func add(src: Rect2, dst: Rect2, flip_v: bool = false) -> void:
	_ops.append([src, dst, flip_v])


func _draw() -> void:
	if texture == null:
		return
	for op in _ops:
		var src: Rect2 = op[0]
		var dst: Rect2 = op[1]
		if op[2]:
			# Retournement vertical : on dessine sous une transformation d'échelle (1, -1).
			draw_set_transform(Vector2(dst.position.x, dst.end.y), 0.0, Vector2(1, -1))
			draw_texture_rect_region(texture, Rect2(Vector2.ZERO, dst.size), src)
			draw_set_transform(Vector2.ZERO, 0.0, Vector2.ONE)
		else:
			draw_texture_rect_region(texture, dst, src)
